using ProductFeed;
using System;
using Xunit;

namespace ProductFeedTest
{
    public class MyCliTest
    {
        public MyCliTest()
        {

        }

        [Fact]
        public void ProcessFeedTest()
        {
            string testPath = @"C:\feed-products\softwareadvice.json";
            MyCli mc = new MyCli();
            mc.ProcessFeed(testPath);

            // Assert.True(true);
        }
    }
}
