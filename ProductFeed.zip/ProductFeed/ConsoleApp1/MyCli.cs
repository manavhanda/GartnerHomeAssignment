﻿using CommandLineTool.Attributes;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using YamlDotNet.RepresentationModel;

namespace ProductFeed
{
    [App("my application")]
    public class MyCli
    {
        [Command("import", "using options")]
        public void ProcessFeed([ParamArgument()] string path)
        {
            string ext = Path.GetExtension(path);
            ProcessFeedFile(ext, path);
        }

        public void ProcessFeedFile(string extn, string path)
        {
            if (extn == ".yaml")
            {
                using (var reader = new StreamReader(path))
                {
                    // Load the stream
                    var yaml = new YamlStream();
                    yaml.Load(reader);

                    var mapping2 = (YamlSequenceNode)yaml.Documents[0].RootNode;

                    List<YamlNode> yn = (List<YamlNode>)mapping2.Children;

                    foreach (YamlMappingNode item in yn)
                    {
                        string tagsValue = string.Empty;
                        string nameValue = string.Empty;
                        string twitterValue = string.Empty;
                        foreach (var child in item.Children)
                        {
                            string paramName = child.Key.ToString();
                            // Assign value to parameter.
                            if (paramName == "name")
                            {
                                nameValue = child.Value.ToString();
                            }

                            if (paramName == "tags")
                            {
                                tagsValue = child.Value.ToString();
                            }

                            if (paramName == "twitter")
                            {
                                twitterValue = child.Value.ToString();
                            }
                        }

                        Console.WriteLine("importing: Name: \"" + nameValue + "\"" + "; Categories: " + tagsValue + "; Twitter: @" + twitterValue);
                    }
                }
            }
            else if (extn == ".json")
            {
                using (StreamReader r = new StreamReader(path))
                {
                    string json = r.ReadToEnd();
                    JObject obj = JObject.Parse(json);

                    JToken value;
                    if (obj.TryGetValue("products", out value))
                    {
                        var objResponse2 = JsonConvert.DeserializeObject<List<Product>>(value.ToString());

                        foreach (var data in objResponse2)
                        {
                            string tagsValue = string.Empty;
                            string nameValue = string.Empty;
                            string twitterValue = string.Empty;

                            for (int i = 0; i < data.categories.Count; i++)
                            {
                                tagsValue = tagsValue + data.categories[i] + ",";
                            }
                            nameValue = data.title;
                            twitterValue = data.twitter;

                            Console.WriteLine("importing: Name: \"" + nameValue + "\"" + "; Categories: " + tagsValue + "; Twitter: @" + twitterValue);
                        }
                    }
                }
            }
        }
    }
}