﻿using System;
using CommandLineTool;

namespace ProductFeed
{
    class Program
    {
        static void Main(string[] args)
        {
            Cli cli = new(typeof(MyCli))
            {
                Introduction = "Product Feed Reading Tool",
                PromptText = "$"
            };
            //optional: set list of keys to exit from the command loop
            cli.SetCancellationKeys(new() { "exit" });
            cli.Start();
        }
    }
}
